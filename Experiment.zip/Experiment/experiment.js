
var helpContent;
var infoContent;
var voltage;
var resistance;
var water;
/*var reservoirwater1;
var reservoirwater2;
var reservoirwater3;
var reservoirwater4;
var reservoirwater5;
var reservoirwater6;
var reservoirwater7;
var reservoirwater8;*/
var thermo;
var thermoinner;
var swi;
var flag;
var test;
var test2;
var power;
var clock;
var sec=[];
var min=[];
var reading=[];
var a;
var b;
var c;
var time;
var temp;
var check;
var t;
var degree;
var tempint;
var speed;
var tableindex1;
var lm;
var lscreen;
var x;
var rcase;
var bflag;
var wcase;

function initialiseHelp()
{
    helpContent="";
    helpContent = helpContent + "<h2>Heating calculations of electric current help</h2>";
    helpContent = helpContent + "<h3>About the experiment</h3>";
    helpContent = helpContent + "<p>Shown the calculation of Electric Energy and Heat Energy in Joules.<p>";
	helpContent = helpContent + "<p>The running time of an experiment is calculated through the stopwatch.</p>";
    helpContent = helpContent + "<h3>Animation control for Experiment Mode</h3>";
    helpContent = helpContent + "<p>Select the values of voltage, resistance and quantity of water through the slider</p>";
    helpContent = helpContent + "<p>The Joule Meter shows the power consumed by the resistance.</p>";
	helpContent = helpContent + "<p>The Electric Energy is calculated which is the product of power and time elapsed.</p>";
	helpContent = helpContent + "<p>The Heat Energy is calculated which is the product of Mass of Water, Change in Temperature and Specific Heat Capacity of Water</p>";
	helpContent = helpContent + "<p>The table gets filled as the animation starts.</p>";
    helpContent = helpContent + "<p>Click on pause button to pause the animation</p>";
    helpContent = helpContent + "<p>Click on Reset button to reset animation</p>";
	helpContent = helpContent + "<h3>Animation control for Learning Mode</h3>";
	helpContent = helpContent + "<p>The values of voltage, resistance and quantity of water are randomly selected. You can also select the value from the slider.</p>";
    helpContent = helpContent + "<p>The Joule Meter shows the power consumed by the resistance.</p>";
	helpContent = helpContent + "<p>The table gets filled as the animation is started.</p>";
    helpContent = helpContent + "<p>The value of the Heat Energy should be calculated by the user.</p>";
	helpContent = helpContent + "<p>Enter the calculated value of Heat Energy to check whether if it is correct or not.</p>";
	helpContent = helpContent + "<p>Click on pause button to pause the animation</p>";
    helpContent = helpContent + "<p>Click on Reset button to reset animation</p>";
    infoContent = infoContent + "<h2>Happy Experimenting</h2>";
    PIEupdateHelp(helpContent);
}

function initialiseInfo()
{
    infoContent =  "";
    infoContent = infoContent + "<h2>Heating calculations of electric current concepts</h2>";
    infoContent = infoContent + "<h3>About the experiment</h3>";
    infoContent = infoContent + "<p>Shown the calculation of Electric Energy and Heat Energy in Joules.</p>";
    infoContent = infoContent + "<p>The power consumed by the resistance is shown by the Joule Meter in Watts.</p>";
	infoContent = infoContent + "<p>The Electric Energy is calculated as :-</p>";
	infoContent = infoContent + "<h3>Electric Energy = Power x Time</h3>";
	infoContent = infoContent + "<p>The Heat Energy is calculated as :-</p>";
	infoContent = infoContent + "<h3>Heat Energy = (Volume of Water x Density) x (Change in Temperature) x (Specific Heat Capacity of Water) </h3>";
	infoContent = infoContent + "<p>Moreover, by the Conservation of Energy concept :-</p>";
	infoContent = infoContent + "<h3>Electric Energy (lost) = Heat Energy (gained)</h3>";
	infoContent = infoContent + "<p>The Specific Heat Capacity of water is taken as 4.186 J/L ?C</p>";
	infoContent = infoContent + "<p>The Stop Watch shows the time elapsed.</p>";
	
    PIEupdateInfo(infoContent);
}

function addSwitch()
{
	var geometry = new THREE.CubeGeometry(2,0.2,6);
	var box=new THREE.Mesh(geometry,new THREE.MeshBasicMaterial({color:"brown"}));
	box.position.set(0,-5.5,0);
	box.rotation.x-=Math.PI/30;
	PIEaddElement(box);
	
	var edge = new THREE.LineSegments(new THREE.EdgesGeometry(geometry),new THREE.LineBasicMaterial({color:"black",linewidth:1}));
	box.add(edge);
	
	var geometry = new THREE.CubeGeometry(0.15,0.2,0.2);
	var clip1=new THREE.Mesh(geometry,new THREE.MeshBasicMaterial({color:"grey"}));
	clip1.rotation.x+=Math.PI/20;
	clip1.position.set(-0.65,0.2,0.3);
	box.add(clip1);
	
	var edge = new THREE.LineSegments(new THREE.EdgesGeometry(geometry),new THREE.LineBasicMaterial({color:"black",linewidth:0.7}));
	clip1.add(edge);
	
	var geometry = new THREE.CubeGeometry(0.15,0.2,0.2);
	var clip2=new THREE.Mesh(geometry,new THREE.MeshBasicMaterial({color:"grey"}));
	clip2.rotation.x+=Math.PI/20;
	clip2.position.set(0.65,0.2,0.3);
	box.add(clip2);
	
	var edge = new THREE.LineSegments(new THREE.EdgesGeometry(geometry),new THREE.LineBasicMaterial({color:"black",linewidth:0.7}));
	clip2.add(edge);
	
	var geometry = new THREE.CubeGeometry(1.5,0.1,0.1);
	swi=new THREE.Mesh(geometry,new THREE.MeshBasicMaterial({color:"black"}));
	swi.position.set(0,-5.1,0);
	swi.rotation.z=Math.PI/10;
	PIEaddElement(swi);
	
	var edge = new THREE.LineSegments(new THREE.EdgesGeometry(geometry),new THREE.LineBasicMaterial({color:"grey",linewidth:0.7}));
	swi.add(edge);
	
	PIEsetClick(box,switchonstart);
}

function switchon()
{
	swi.position.set(0,-5.2,0.2);
	swi.rotation.z=Math.PI/50;
}

function switchoff()
{
	swi.position.set(0,-5.1,0);
	swi.rotation.z=Math.PI/10;
}

function switchonstart()
{
if(flag==0)
{
switchon();
PIEstartAnimation();
}	
else
{
	switchoff();
	PIEstopAnimation();
}
}

function addVoltagesource()
{
	var geometry = new THREE.CubeGeometry(3.2,2.2,2);
	var base=new THREE.Mesh(geometry,new THREE.MeshBasicMaterial({color:"white"}));
	//base.rotation.y-=Math.PI/20;
	base.rotation.x+=Math.PI/90;
	base.position.set(-4.8,-2.5,-2);
	PIEaddElement(base);
		
	var wireframe = new THREE.LineSegments( new THREE.EdgesGeometry(geometry), new THREE.LineBasicMaterial( { color: "black", linewidth: 1} ) );
	base.add(wireframe);
	
	var base2=new THREE.Mesh(new THREE.PlaneGeometry(2.75,1.75,2),new THREE.MeshBasicMaterial({color:"grey"}));
	base2.position.set(-4.55,-2.5,0);
	base2.rotation.x+=Math.PI/90;
	PIEaddElement(base2);
	
	var screen=new THREE.Mesh(new THREE.PlaneGeometry(1.8,0.6,2),new THREE.MeshBasicMaterial({color:"black"}));
	screen.position.set(-4.55,-2.1,0.1);
	screen.rotation.x+=Math.PI/90;
	PIEaddElement(screen);
	
	var p=new THREE.Mesh(new THREE.CircleGeometry(0.15,32),new THREE.MeshBasicMaterial({color:0x8b0000}));
	p.position.set(-5.2,-2.8,1);
	p.rotation.x+=Math.PI/90;
	PIEaddElement(p);
	
	var n=new THREE.Mesh(new THREE.CircleGeometry(0.15,32),new THREE.MeshBasicMaterial({color:"black"}));
	n.position.set(-3.48,-2.8,1);
	n.rotation.x+=Math.PI/90;
	PIEaddElement(n);
	
	
	var loader = new THREE.FontLoader();
    loader.load("optimer.json", function(response){
        font = response;
		
		geometry = new THREE.TextGeometry('+', {
        	font : font,
            size : 0.20,
            height : 0.03,
        });
		var ip=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:0x8b0000}));
        ip.translation = geometry.center();
        PIEaddElement(ip);
        ip.castShadow=false;
        ip.visible=true;
        ip.position.set(-4.9,-2.8,1); 
		
		geometry = new THREE.TextGeometry('_', {
        	font : font,
            size : 0.20,
            height : 0.03,
        });
		
		var ip=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:"black"}));
        ip.translation = geometry.center();
        PIEaddElement(ip);
        ip.castShadow=false;
        ip.visible=true;
        ip.position.set(-3.8,-2.8,1); 
	
	PIErender();
	});
}

function addBubble()
{
	bubble1=new THREE.Mesh(new THREE.SphereGeometry(0.07,0.07,100),new THREE.MeshPhongMaterial({color:"white"}));//,transparent:true,opacity:0.8}));
	bubble1.position.set(5.85,-5.3,0);
	PIEaddElement(bubble1);
	
	bubble2=new THREE.Mesh(new THREE.SphereGeometry(0.07,0.07,100),new THREE.MeshPhongMaterial({color:"white"}));//,transparent:true,opacity:0.8}));
	bubble2.position.set(5.85+0.15+0.02,-5.3,0);
	PIEaddElement(bubble2);
	
	bubble3=new THREE.Mesh(new THREE.SphereGeometry(0.07,0.07,100),new THREE.MeshPhongMaterial({color:"white"}));//,transparent:true,opacity:0.8}));
	bubble3.position.set(5.85+0.30+0.02,-5.3,0);
	PIEaddElement(bubble3);
	
	bubble4=new THREE.Mesh(new THREE.SphereGeometry(0.07,0.07,100),new THREE.MeshPhongMaterial({color:"white"}));//,transparent:true,opacity:0.8}));
	bubble4.position.set(5.85+0.45+0.02,-5.3,0);
	PIEaddElement(bubble4);
	
	bubble5=new THREE.Mesh(new THREE.SphereGeometry(0.07,0.07,100),new THREE.MeshPhongMaterial({color:"white"}));//,transparent:true,opacity:0.8}));
	bubble5.position.set(5.85+0.60+0.02,-5.3,0);
	PIEaddElement(bubble5);
	
	bubble6=new THREE.Mesh(new THREE.SphereGeometry(0.07,0.07,100),new THREE.MeshPhongMaterial({color:"white"}));//,transparent:true,opacity:0.8}));
	bubble6.position.set(5.85+0.75+0.02,-5.3,0);
	PIEaddElement(bubble6);
	
	bubble7=new THREE.Mesh(new THREE.SphereGeometry(0.07,0.07,100),new THREE.MeshPhongMaterial({color:"white"}));//,transparent:true,opacity:0.8}));
	bubble7.position.set(5.85+0.90+0.02,-5.3,0);
	PIEaddElement(bubble7);
	
	bubble8=new THREE.Mesh(new THREE.SphereGeometry(0.07,0.07,100),new THREE.MeshPhongMaterial({color:"white"}));//,transparent:true,opacity:0.8}));
	bubble8.position.set(5.85+1.05+0.02,-5.3,0);
	PIEaddElement(bubble8);
	
	bubble9=new THREE.Mesh(new THREE.SphereGeometry(0.07,0.07,100),new THREE.MeshPhongMaterial({color:"white"}));//,transparent:true,opacity:0.8}));
	bubble9.position.set(5.85+1.2+0.02,-5.3,0);
	PIEaddElement(bubble9);
	
	bubble10=new THREE.Mesh(new THREE.SphereGeometry(0.07,0.07,100),new THREE.MeshPhongMaterial({color:"white"}));//,transparent:true,opacity:0.8}));
	bubble10.position.set(5.85+1.35+0.02,-5.3,0);
	PIEaddElement(bubble10);
	
	bubble1.visible=false;
	bubble2.visible=false;
	bubble3.visible=false;
	bubble4.visible=false;
	bubble5.visible=false;
	bubble6.visible=false;
	bubble7.visible=false;
	bubble9.visible=false;
	bubble8.visible=false;
	bubble10.visible=false;
}

function addResistance()
{
	var geometry = new THREE.TorusGeometry( 0.4, 0.05, 12, 100 );
	var material = new THREE.MeshPhongMaterial( { color:0xa4672d,sharpness:40 } );
	torus = new THREE.Mesh( geometry, material );
	torus.position.set(6,-4.8,1);
	torus.rotation.y+=Math.PI/2;
	torus.visible=false;
	PIEaddElement(torus);
	
	torus1 = new THREE.Mesh(new THREE.TorusGeometry( 0.4, 0.05, 12, 100 ),new THREE.MeshPhongMaterial( { color:0xa4672d,sharpness:40 } ));
	torus1.position.set(0,0,0.15);
	torus1.visible=false;
	torus.add(torus1);
	
	torus2 = new THREE.Mesh(new THREE.TorusGeometry( 0.4, 0.05, 12, 100 ),new THREE.MeshPhongMaterial( { color:0xa4672d,sharpness:40 } ));
	torus2.position.set(0,0,0.30);
	torus2.visible=false;
	torus.add(torus2);
	
	torus3 = new THREE.Mesh(new THREE.TorusGeometry( 0.4, 0.05, 12, 100 ),new THREE.MeshPhongMaterial( { color:0xa4672d,sharpness:40 } ));
	torus3.position.set(0,0,0.45);
	torus3.visible=false;
	torus.add(torus3);
	
	torus4 = new THREE.Mesh(new THREE.TorusGeometry( 0.4, 0.05, 12, 100 ),new THREE.MeshPhongMaterial( { color:0xa4672d,sharpness:40 } ));
	torus4.position.set(0,0,-0.15);
	torus4.visible=false;
	torus.add(torus4);
	
	torus5 = new THREE.Mesh(new THREE.TorusGeometry( 0.4, 0.05, 12, 100 ),new THREE.MeshPhongMaterial( { color:0xa4672d,sharpness:40 } ));
	torus5.position.set(0,0,0.60);
	torus5.visible=false;
	torus.add(torus5);
	
	torus6 = new THREE.Mesh(new THREE.TorusGeometry( 0.4, 0.05, 12, 100 ),new THREE.MeshPhongMaterial( { color:0xa4672d,sharpness:40 } ));
	torus6.position.set(0.1,0,-0.3);
	torus6.visible=false;
	torus.add(torus6);
	
	torus7 = new THREE.Mesh(new THREE.TorusGeometry( 0.4, 0.05, 12, 100 ),new THREE.MeshPhongMaterial( { color:0xa4672d,sharpness:40 } ));
	torus7.position.set(0,0,0.75);
	torus7.visible=false;
	torus.add(torus7);
	
	torus8 = new THREE.Mesh(new THREE.TorusGeometry( 0.4, 0.05, 12, 100 ),new THREE.MeshPhongMaterial( { color:0xa4672d,sharpness:40 } ));
	torus8.position.set(0,0,0.90);
	torus8.visible=false;
	torus.add(torus8);
	
	torus9 = new THREE.Mesh(new THREE.TorusGeometry( 0.4, 0.05, 12, 100 ),new THREE.MeshPhongMaterial( { color:0xa4672d,sharpness:40 } ));
	torus9.position.set(0,0,1.05);
	torus9.visible=false;
	torus.add(torus9);
	
	var rod = new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,2.1,100),new THREE.MeshPhongMaterial( { color:0xa4672d,sharpness:40 } ));
	rod.rotation.z=Math.PI/2;
	rod.position.set(6.55,-4.57,0);
	PIEaddElement(rod);
	
	var rod1 = new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,5.8,100),new THREE.MeshPhongMaterial( { color:0xa4672d,sharpness:40 } ));
	rod1.position.set(7.57,-1.67,0);
	PIEaddElement(rod1);
	
	var rod2 = new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,5.5,100),new THREE.MeshPhongMaterial( { color:0xa4672d,sharpness:40 } ));
	rod2.position.set(5.53,-1.85,0);
	PIEaddElement(rod2);
}

function addThermometer()
{
    thermo=new THREE.Mesh(new THREE.PlaneGeometry(0.3,3,2),new THREE.MeshBasicMaterial({color:"black"}));
	thermo.position.set(3+1,0,0);
	PIEaddElement(thermo);
	
	//var thermomerc=new THREE.Mesh(new THREE.PlaneGeometry(0.2,3,2),new THREE.MeshBasicMaterial({color:0x343434}));
	var thermomerc=new THREE.Mesh(new THREE.PlaneGeometry(0.2,3,2),new THREE.MeshBasicMaterial({color:"red"}));
	thermomerc.position.set(0,0.07,0);
	thermo.add(thermomerc);
	
	thermoinner=new THREE.Mesh(new THREE.PlaneGeometry(0.2,3,2),new THREE.MeshBasicMaterial({color:"white"}));
	thermoinner.position.set(0,0.07,0);
	thermo.add(thermoinner);
	
	var thermoplane=new THREE.Mesh(new THREE.PlaneGeometry(0.2,8,2),new THREE.MeshBasicMaterial({color:0x329acd}));
	//var thermoplane=new THREE.Mesh(new THREE.PlaneGeometry(0.31,8,2),new THREE.MeshBasicMaterial({color:"white"}));
	thermoplane.position.set(0,5.5,0.001);
	thermo.add(thermoplane);
	
	var thermoline=new THREE.Mesh(new THREE.PlaneGeometry(0.3,0.07,2),new THREE.MeshBasicMaterial({color:"black"}));
	thermoline.position.set(0,1.5,0.01);
	thermo.add(thermoline);
	
	for(var i=-14;i<15;i++)
	{
		var temp=new THREE.Mesh(new THREE.PlaneGeometry(0.10,0.020,2),new THREE.MeshBasicMaterial({color:"black"}));
		temp.position.set(0.07,i/10,0);
		thermo.add(temp);
	}

	var test=new THREE.Mesh(new THREE.CylinderGeometry(0.22,0.22,3.1,100),new THREE.MeshPhongMaterial({color:"blue", transparent: true, opacity:0.1,shininess:40}));
	test.position.set(0,0.06,-0.01);
	thermo.add(test);
	
	var test2=new THREE.Mesh(new THREE.SphereGeometry(0.22,0.22,1000),new THREE.MeshPhongMaterial({color:"blue", transparent: true, opacity:0.1}));
	test2.position.set(0,1.55,-0.01);
	thermo.add(test2);
	
	var met=new THREE.Mesh(new THREE.SphereGeometry(0.22,0.22,1000),new THREE.MeshPhongMaterial({color:"black", transparent: true, opacity:1,shininess:20}));
	met.position.set(0,-1.4,-0.01);
	thermo.add(met);
	
	var tip1= new THREE.Mesh(new THREE.CylinderGeometry(0.07,0.07,0.6,100),new THREE.MeshPhongMaterial({color:"black"}));
	tip1.position.set(0,-2+0.15,0);
	thermo.add(tip1);
	
	var tip2= new THREE.Mesh(new THREE.SphereGeometry(0.07,0.07,100),new THREE.MeshPhongMaterial({color:"black"}));
	tip2.position.set(0,-2.32+0.15,0);
	thermo.add(tip2);
	
	thermo.position.x+=4.5;
	
	temparray=new Array;
	
	var loader = new THREE.FontLoader();
    loader.load("optimer.json", function(response){
        font = response;
	
	geometry = new THREE.TextGeometry('o', {
        	font : font,
            size : 0.1,
            height : 0.05,
        });	
		
	degree=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:"black"}));
	degree.translation=geometry.center();
	thermo.add(degree);
	degree.castShadow=false;
    degree.visible=true;
    degree.position.set(1.07,0.07,0.2); 
		
	for(var i=27;i<101;i++)
	{
		if(i<10)
			x='0'+i;
		else
			x=i;
		geometry = new THREE.TextGeometry(i+'  C', {
        	font : font,
            size : 0.2,
            height : 0.05,
        });
		var temp=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:"black"}));
        temp.translation = geometry.center();
        thermo.add(temp);
        temp.castShadow=false;
        temp.visible=false;
        temp.position.set(1,0,0.2); 
   		temp.lookAt(PIEcamera.position);
		temparray.push(temp);
	}
	
	reading=temparray.slice();
	reading[0].visible=true;
	PIErender();
	});
	
	thermoinner.position.y=27/35+0.15;
}

function addContainer()
{
	var cylinder=new THREE.Mesh(new THREE.CylinderGeometry(2,2,5,100),new THREE.MeshPhongMaterial({color:"white", transparent: true, opacity:0.2}));
	cylinder.position.set(7,-3.3,0);
	cylinder.rotation.y=-Math.PI/3;
	PIEaddElement(cylinder);
	
	reservoirwater1=new THREE.Mesh(new THREE.CylinderGeometry(1.9,1.9,4.9,10000),new THREE.MeshBasicMaterial({color:"blue", transparent: true, opacity:0.4}));
	reservoirwater1.position.set(7,-3.3,-0.001);
	reservoirwater1.visible=false;
	PIEaddElement(reservoirwater1);
	
	reservoirwater2=new THREE.Mesh(new THREE.CylinderGeometry(1.9,1.9,4.5,10000),new THREE.MeshBasicMaterial({color:"blue", transparent: true, opacity:0.4}));
	reservoirwater2.position.set(7,-3.5,-0.001);
	reservoirwater2.visible=false;
	PIEaddElement(reservoirwater2);
	
	reservoirwater3=new THREE.Mesh(new THREE.CylinderGeometry(1.9,1.9,4,10000),new THREE.MeshBasicMaterial({color:"blue", transparent: true, opacity:0.4}));
	reservoirwater3.position.set(7,-3.75,-0.001);
	reservoirwater3.visible=false;
	PIEaddElement(reservoirwater3);
	
	reservoirwater4=new THREE.Mesh(new THREE.CylinderGeometry(1.9,1.9,3.5,10000),new THREE.MeshBasicMaterial({color:"blue", transparent: true, opacity:0.4}));
	reservoirwater4.position.set(7,-4.0,-0.001);
	reservoirwater4.visible=false;
	PIEaddElement(reservoirwater4);
	
	reservoirwater5=new THREE.Mesh(new THREE.CylinderGeometry(1.9,1.9,3,10000),new THREE.MeshBasicMaterial({color:"blue", transparent: true, opacity:0.4}));
	reservoirwater5.position.set(7,-4.25,-0.001);
	reservoirwater5.visible=false;
	PIEaddElement(reservoirwater5);
	
	reservoirwater6=new THREE.Mesh(new THREE.CylinderGeometry(1.9,1.9,2.5,10000),new THREE.MeshBasicMaterial({color:"blue", transparent: true, opacity:0.4}));
	reservoirwater6.position.set(7,-4.5,-0.001);
	reservoirwater6.visible=false;
	PIEaddElement(reservoirwater6);
	
	reservoirwater7=new THREE.Mesh(new THREE.CylinderGeometry(1.9,1.9,2,10000),new THREE.MeshBasicMaterial({color:"blue", transparent: true, opacity:0.4}));
	reservoirwater7.position.set(7,-4.75,-0.001);
	reservoirwater7.visible=false;
	PIEaddElement(reservoirwater7);
	
	reservoirwater8=new THREE.Mesh(new THREE.CylinderGeometry(1.9,1.9,1.5,10000),new THREE.MeshBasicMaterial({color:"blue", transparent: true, opacity:0.4}));
	reservoirwater8.position.set(7,-4.95,-0.001);
	reservoirwater8.visible=false;
	PIEaddElement(reservoirwater8);
}

function addJoulesmeter()
{
	var geometry = new THREE.CubeGeometry(4,2.8,3);
	var base=new THREE.Mesh(geometry,new THREE.MeshBasicMaterial({color:"grey"}));
	base.rotation.y-=Math.PI/20;
	base.rotation.x+=Math.PI/20;
	base.position.set(0,2,-2);
	PIEaddElement(base);
		
	var wireframe = new THREE.LineSegments( new THREE.EdgesGeometry(geometry), new THREE.LineBasicMaterial( { color: "black", linewidth: 1} ) );
	base.add(wireframe);
	
	var base2=new THREE.Mesh(new THREE.PlaneGeometry(3.6,2.45,2),new THREE.MeshBasicMaterial({color:"white"}));
	base2.position.set(-0.2,1.72,0);
	base2.rotation.y-=Math.PI/20;
	base2.rotation.x+=Math.PI/20;
	PIEaddElement(base2);
	
	var icp=new THREE.Mesh(new THREE.CircleGeometry(0.08,32),new THREE.MeshBasicMaterial({color:"red"}));
	icp.position.set(-1.5,1.1,1);
	icp.rotation.y-=Math.PI/20;
	icp.rotation.x+=Math.PI/20;
	PIEaddElement(icp);
	
	var icn=new THREE.Mesh(new THREE.CircleGeometry(0.08,32),new THREE.MeshBasicMaterial({color:"black"}));
	icn.position.set(-1.5,0.8,1);
	icn.rotation.y-=Math.PI/20;
	icn.rotation.x+=Math.PI/20;
	PIEaddElement(icn);
	
	var ocp=new THREE.Mesh(new THREE.CircleGeometry(0.08,32),new THREE.MeshBasicMaterial({color:"red"}));
	ocp.position.set(1.2,1.1,1);
	ocp.rotation.y-=Math.PI/20;
	ocp.rotation.x+=Math.PI/20;
	PIEaddElement(ocp);
	
	var ocn=new THREE.Mesh(new THREE.CircleGeometry(0.08,32),new THREE.MeshBasicMaterial({color:"black"}));
	ocn.position.set(1.2,0.8,1);
	ocn.rotation.y-=Math.PI/20;
	ocn.rotation.x+=Math.PI/20;
	PIEaddElement(ocn);
	
	var loader = new THREE.FontLoader();
    loader.load("optimer.json", function(response){
        font = response;
		
		geometry = new THREE.TextGeometry('+', {
        	font : font,
            size : 0.17,
            height : 0.03,
        });
		var ip=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:"red"}));
        ip.translation = geometry.center();
        PIEaddElement(ip);
        ip.castShadow=false;
        ip.visible=true;
        ip.position.set(-0.9,0.7,5); 
		
		var op=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:"red"}));
        op.translation = geometry.center();
        PIEaddElement(op);
        op.castShadow=false;
        op.visible=true;
        op.position.set(0.85,0.7,5);
		
		geometry = new THREE.TextGeometry('_', {
        	font : font,
            size : 0.17,
            height : 0.03,
        });
		
		var on=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:"black"}));
        on.translation = geometry.center();
        PIEaddElement(on);
        on.castShadow=false;
        on.visible=true;
        on.position.set(0.85,0.45,5);
		
		var ain=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:"black"}));
        ain.translation = geometry.center();
        PIEaddElement(ain);
        ain.castShadow=false;
        ain.visible=true;
        ain.position.set(-0.9,0.45,5);
		
		geometry = new THREE.TextGeometry('I/P', {
        	font : font,
            size : 0.12,
            height : 0.03,
        });
		
		var ain2=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:"black"}));
        ain2.translation = geometry.center();
        PIEaddElement(ain2);
        ain2.castShadow=false;
        ain2.visible=true;
        ain2.position.set(-1,0.9,5);
		
		geometry = new THREE.TextGeometry('O/P', {
        	font : font,
            size : 0.12,
            height : 0.03,
        });
		
		var ain22=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:"black"}));
        ain22.translation = geometry.center();
        PIEaddElement(ain22);
        ain22.castShadow=false;
        ain22.visible=true;
        ain22.position.set(0.95,0.9,5);
		
		PIErender();
	});
	
	var screen = new THREE.Mesh(new THREE.PlaneGeometry(2.8,0.9,2),new THREE.MeshBasicMaterial({color:"black"}));
	screen.rotation.y-=Math.PI/20;
	screen.position.set(-0.2,2.1,0.5);
	screen.rotation.x+=Math.PI/20;
	PIEaddElement(screen);
	
	/*var loader = new THREE.FontLoader();
    loader.load("Digital.json", function(response){
        font = response;
		
		geometry = new THREE.TextGeometry('230 kW', {
        	font : font,
            size : 0.25,
            height : 0.03,
        });
		var test=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:"red"}));
        test.translation = geometry.center();
        PIEaddElement(test);
        test.castShadow=false;
        test.visible=true;
        test.position.set(0,1.3,5); 
	});*/
	
	var l1=new THREE.Mesh(new THREE.CylinderGeometry(0.03,0.03,6.2,100),new THREE.MeshPhongMaterial({color:"black"}));
	l1.rotation.z+=Math.PI/2;
	l1.position.set(4.25,1.15,0.5);
	PIEaddElement(l1);
	
	var l2=new THREE.Mesh(new THREE.CylinderGeometry(0.03,0.03,4.25,100),new THREE.MeshPhongMaterial({color:"black"}));
	l2.rotation.z+=Math.PI/2;
	l2.position.set(3.29,0.85,0.5);
	PIEaddElement(l2);
	
	var l3=new THREE.Mesh(new THREE.CylinderGeometry(0.03,0.03,1,100),new THREE.MeshPhongMaterial({color:"black"}));
	l3.rotation.z+=Math.PI/2;
	l3.position.set(-2,1.15,0.5);
	PIEaddElement(l3);
	
	var l4=new THREE.Mesh(new THREE.CylinderGeometry(0.03,0.03,1.7,100),new THREE.MeshPhongMaterial({color:"black"}));
	l4.position.set(-2.48,0.3,0.5);
	PIEaddElement(l4);
	
	var l5=new THREE.Mesh(new THREE.CylinderGeometry(0.03,0.03,3.8,100),new THREE.MeshPhongMaterial({color:"black"}));
	l5.rotation.z+=Math.PI/2;
	l5.position.set(-4.4,-0.52,0.5);
	PIEaddElement(l5);
	
	var l6=new THREE.Mesh(new THREE.CylinderGeometry(0.03,0.03,2.35,100),new THREE.MeshPhongMaterial({color:"black"}));
	l6.position.set(-6.3,-1.67,0.5);
	PIEaddElement(l6);
	
	var l7=new THREE.Mesh(new THREE.CylinderGeometry(0.03,0.03,1,100),new THREE.MeshPhongMaterial({color:"black"}));
	l7.rotation.z+=Math.PI/2;
	l7.position.set(-5.82,-2.85,0.5);
	PIEaddElement(l7);
	
	var l8=new THREE.Mesh(new THREE.CylinderGeometry(0.03,0.03,1.3,100),new THREE.MeshPhongMaterial({color:"black"}));
	l8.rotation.z+=Math.PI/2;
	l8.position.set(-3,-2.85,0.5);
	PIEaddElement(l8);
	
	var l9=new THREE.Mesh(new THREE.CylinderGeometry(0.03,0.03,2.4,100),new THREE.MeshPhongMaterial({color:"black"}));
	l9.position.set(-2.38,-4.05,0.5);
	PIEaddElement(l9);
	
	var l10=new THREE.Mesh(new THREE.CylinderGeometry(0.03,0.03,1.65,100),new THREE.MeshPhongMaterial({color:"black"}));
	l10.rotation.z+=Math.PI/2;
	l10.position.set(-1.55,-5.22,0.5);
	PIEaddElement(l10);
	
	////////////////////
	
	var l11=new THREE.Mesh(new THREE.CylinderGeometry(0.03,0.03,1.4,100),new THREE.MeshPhongMaterial({color:"black"}));
	l11.position.set(-1.55,0.1,0.5);
	PIEaddElement(l11);
	
	var l12=new THREE.Mesh(new THREE.CylinderGeometry(0.03,0.03,4.9,100),new THREE.MeshPhongMaterial({color:"black"}));
	l12.rotation.z+=Math.PI/2;
	l12.position.set(0.88,-0.6,0.5);
	PIEaddElement(l12);
	
	var l13=new THREE.Mesh(new THREE.CylinderGeometry(0.03,0.03,4.6,100),new THREE.MeshPhongMaterial({color:"black"}));
	l13.position.set(3.3,-2.9,0.5);
	PIEaddElement(l13);
	
	var l14=new THREE.Mesh(new THREE.CylinderGeometry(0.03,0.03,2.6,100),new THREE.MeshPhongMaterial({color:"black"}));
	l14.rotation.z+=Math.PI/2;
	l14.position.set(2.02,-5.22,0.5);
	PIEaddElement(l14);
}

function pro()
{
	var y = prompt("Enter Value of Heat Energy (in Joules, correct to exactly 2 decimal places)", "0");
	if(x==y)
			alert("CORRECT");
	else
		alert("INCORRECT, TRY AGAIN");
}

function learningthings()
{
	lscreen=new THREE.Mesh(new THREE.PlaneGeometry(4.5,1.2,1),new THREE.MeshBasicMaterial({color:0x98FB98}));
	lscreen.visible=false;
	PIEaddElement(lscreen);
	lscreen.position.set(-8,1,0);
	
	var loader = new THREE.FontLoader();
    loader.load("optimer.json", function(response){
        font = response;
		
		geometry = new THREE.TextGeometry('Click here to enter value of', {
        	font : font,
            size : 0.19,
            height : 0.03,
        });
	
	var msg=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:"black"}));
    msg.translation = geometry.center();
    lscreen.add(msg);
    msg.castShadow=false;
    msg.visible=true;
    msg.position.set(0.25,0.1,1);  
	
	geometry = new THREE.TextGeometry('Heat Energy', {
        	font : font,
            size : 0.19,
            height : 0.03,
        });
	
	var msg2=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:"black"}));
    msg2.translation = geometry.center();
    lscreen.add(msg2);
    msg2.castShadow=false;
    msg2.visible=true;
    msg2.position.set(0.2,-0.3,1);  
	PIErender();
	});
	
	PIEsetClick(lscreen,pro);
}

function voltagecontrol(newValue)
{
	voltage=newValue;
	var loader = new THREE.FontLoader();
    loader.load("Digital.json", function(response){
        font = response;
		
		geometry = new THREE.TextGeometry(voltage+' V', {
        	font : font,
            size : 0.30,
            height : 0.03,
        });
		if(test!=0)
			PIEremoveElement(test);
		test=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:"red"}));
        test.translation = geometry.center();
        PIEaddElement(test);
        test.castShadow=false;
        test.visible=true;
        test.position.set(-4.55,-2.1,0.1); 
		
		PIErender();
	});
}

function powercontrol(v)
{
	power=(v*v)/resistance;
	if(power>99)
		power=power.toFixed(2);
	else
	power=power.toFixed(3);
	var loader = new THREE.FontLoader();
    loader.load("Digital.json", function(response){
        font = response;
		
		geometry = new THREE.TextGeometry(power+' W', {
        	font : font,
            size : 0.35,
            height : 0.03,
        });
		if(test2!=0)
			PIEremoveElement(test2);
		test2=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:"red"}));
        test2.translation = geometry.center();
        PIEaddElement(test2);
        test2.castShadow=false;
        test2.visible=true;
        test2.position.set(-0.2,2.1,0.8); 
		
		PIErender();
	});
}

function clockzero()
{
		for(var i=0;i<60;i++)
		{
			sec[i].visible=false;
			min[i].visible=false;
		}
	sec[0].visible=true;
	min[0].visible=true;
}

function thermozero()
{
	for(var i=0;i<74;i++)
		reading[i].visible=false;
	reading[0].visible=true;
}

function addclocktext()
{
	/*information=document.createElement('div');
    information.style.position="fixed";
    information.style.top = "100px";
    information.style.right = "-440px";
    information.style.width = '100%';
    information.style.textAlign = 'center';
    information.style.color = '#ffffff';
    information.style.fontWeight = 'bold';
    information.style.backgroundColor = 'transparent';
    information.style.zIndex = '1';
    information.style.fontFamily = 'Monospace';
    //var s="bla"
    information.innerHTML = min + ":" + sec;
    document.body.appendChild( information );
    PIErender();*/
	sec2=new Array;
	min2=new Array;
	var x;
	var loader = new THREE.FontLoader();
    loader.load("optimer.json", function(response){
        font = response;
	for(var i=0;i<60;i++)
	{
		if(i<10)
			x='0'+i;
		else
			x=i;
		geometry = new THREE.TextGeometry(':'+x, {
        	font : font,
            size : 0.2,
            height : 0.25,
        });
		var temp=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:"black"}));
        temp.translation = geometry.center();
        PIEaddElement(temp);
        temp.castShadow=false;
        temp.visible=false;
        temp.position.set(4.5+1.05,2.2+0.45,3); 
   		temp.lookAt(PIEcamera.position);
		sec2.push(temp);
		
		geometry = new THREE.TextGeometry(x, {
        	font : font,
            size : 0.2,
            height : 0.25,
        });
		var temp2=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:"black"}));
        temp2.translation = geometry.center();
        PIEaddElement(temp2);
        temp2.castShadow=false;
        temp2.visible=false;
        temp2.position.set(4.1+1.05,2.2+0.45,3); 
   		temp2.lookAt(PIEcamera.position);
		min2.push(temp2);
	}
	sec=sec2.slice();
	min=min2.slice();
	//sec[13].visible=true;
	sec[0].visible=true;
	min[0].visible=true;
	PIErender();
	});
}

function addclock()
{
	var geometry=new THREE.CircleGeometry(0.9,32);
	var material = new THREE.MeshBasicMaterial( {color: "black", side: THREE.DoubleSide} );
	var watch = new THREE.Mesh( geometry, material );
	watch.position.set(6.05,2.75+0.3,0);
	PIEaddElement(watch);
	
	var geometry=new THREE.CircleGeometry(0.8,32);
	var material = new THREE.MeshBasicMaterial( {color: "white", side: THREE.DoubleSide} );
	var watch2 = new THREE.Mesh( geometry, material );
	watch2.position.set(6.05,2.75+0.3,0);
	PIEaddElement(watch2);
	
	var geometry=new THREE.CylinderGeometry(0.1,0.1,0.2);
	var material = new THREE.MeshBasicMaterial( {color: "red", side: THREE.DoubleSide} );
	var watch3 = new THREE.Mesh( geometry, material );
	watch3.position.set(6.05,3.75+0.3,0);
	PIEaddElement(watch3);
}

function calspeed()
{
	speed= power/(4186*water*50);
}

function resistancecontrol(newValue)
{
	resistance=newValue;
	if(resistance==1000)
	{
		torus.visible=true;
		torus1.visible=true;
		torus2.visible=true;
		torus3.visible=true;
		torus4.visible=true;
		torus5.visible=true;
		torus6.visible=true;
		torus7.visible=true;
		torus8.visible=true;
		torus9.visible=true;
		rcase=5;
	}
	else if(resistance>=700)
	{
		torus.visible=true;
		torus1.visible=true;
		torus2.visible=true;
		torus3.visible=true;
		torus4.visible=true;
		torus5.visible=true;
		torus6.visible=true;
		torus7.visible=true;
		torus8.visible=true;
		torus9.visible=false;
		rcase=4;
	}
	else if(resistance>=500)
	{
		torus.visible=true;
		torus1.visible=true;
		torus2.visible=true;
		torus3.visible=true;
		torus4.visible=true;
		torus5.visible=true;
		torus6.visible=false;
		torus7.visible=true;
		torus8.visible=false;
		torus9.visible=false;
		rcase=3;
	}
	else if(resistance>=300)
	{
		torus.visible=true;
		torus1.visible=true;
		torus2.visible=true;
		torus3.visible=true;
		torus4.visible=false;
		torus5.visible=true;
		torus6.visible=false;
		torus7.visible=false;
		torus8.visible=false;
		torus9.visible=false;
		rcase=2;
	}
	else
	{
		torus.visible=true;
		torus1.visible=true;
		torus2.visible=true;
		torus3.visible=true;
		torus4.visible=false;
		torus5.visible=false;
		torus6.visible=false;
		torus7.visible=false;
		torus9.visible=false;
		torus8.visible=false;
		rcase=1;
	}
	PIErender();
}

function watercontrol(newValue)
{
	water=newValue;
	if(water==300)
	{
		reservoirwater8.visible=true;
		reservoirwater7.visible=false;
		reservoirwater6.visible=false;
		reservoirwater5.visible=false;
		reservoirwater4.visible=false;
		reservoirwater3.visible=false;
		reservoirwater2.visible=false;
		reservoirwater1.visible=false;
		thermo.position.y=-2.4;
	}
	else if(water==400)
	{
		reservoirwater8.visible=false;
		reservoirwater7.visible=true;
		reservoirwater6.visible=false;
		reservoirwater5.visible=false;
		reservoirwater4.visible=false;
		reservoirwater3.visible=false;
		reservoirwater2.visible=false;
		reservoirwater1.visible=false;
		thermo.position.y=-2.4+0.4;
	}
	else if(water==500)
	{
		reservoirwater8.visible=false;
		reservoirwater7.visible=false;
		reservoirwater6.visible=true;
		reservoirwater5.visible=false;
		reservoirwater4.visible=false;
		reservoirwater3.visible=false;
		reservoirwater2.visible=false;
		reservoirwater1.visible=false;
		thermo.position.y=-2.4+0.85;
	}
	else if(water==600)
	{
		reservoirwater8.visible=false;
		reservoirwater7.visible=false;
		reservoirwater6.visible=false;
		reservoirwater5.visible=true;
		reservoirwater4.visible=false;
		reservoirwater3.visible=false;
		reservoirwater2.visible=false;
		reservoirwater1.visible=false;
		thermo.position.y=-2.4+1.35;
	}
	else if(water==700)
	{
		reservoirwater8.visible=false;
		reservoirwater7.visible=false;
		reservoirwater6.visible=false;
		reservoirwater5.visible=false;
		reservoirwater4.visible=true;
		reservoirwater3.visible=false;
		reservoirwater2.visible=false;
		reservoirwater1.visible=false;
		thermo.position.y=-2.4+1.85;
	}
	else if(water==800)
	{
		reservoirwater8.visible=false;
		reservoirwater7.visible=false;
		reservoirwater6.visible=false;
		reservoirwater5.visible=false;
		reservoirwater4.visible=false;
		reservoirwater3.visible=true;
		reservoirwater2.visible=false;
		reservoirwater1.visible=false;
		thermo.position.y=-2.4+2.35;
	}
	else if(water==900)
	{
		reservoirwater8.visible=false;
		reservoirwater7.visible=false;
		reservoirwater6.visible=false;
		reservoirwater5.visible=false;
		reservoirwater4.visible=false;
		reservoirwater3.visible=false;
		reservoirwater2.visible=true;
		reservoirwater1.visible=false;
		thermo.position.y=-2.4+2.8;
	}
	else
	{
		reservoirwater8.visible=false;
		reservoirwater7.visible=false;
		reservoirwater6.visible=false;
		reservoirwater5.visible=false;
		reservoirwater4.visible=false;
		reservoirwater3.visible=false;
		reservoirwater2.visible=false;
		reservoirwater1.visible=true;
		thermo.position.y=-2.4+3.2;
	}
	PIErender();
}

function loadExperimentElements()
{
	initialiseHelp();
	initialiseInfo();
	initialisescene();
	addElementsToScene();
	
	PIEsetExperimentTitle("Heating calculations of electric current");
    PIEsetDeveloperName("Aryaman");
	
	if(window.outerWidth<700&&window.outerWidth>600)
	{
		alert(window.outerWidth);
		var q=2.5;
		PIEsetAreaOfInterest(-11*q, 5*q/2.2,12*q,- 7*q/2.2);
	}
	else if(window.outerWidth<=600&&window.outerWidth>450)
	{
		alert(window.outerWidth);
		PIEsetAreaOfInterest(-11*2, 5*1.4,12*2,- 7*1.4);
	}
	else if(window.outerWidth<=450&&window.outerWidth>400)
	{
		alert(window.outerWidth);
		PIEsetAreaOfInterest(-11*4, 5*1.6,12*4,- 7*1.6);
	}
	else if(window.outerWidth<=400)
	{
		alert(window.outerWidth);
		PIEsetAreaOfInterest(-11*5, 5*1.9,12*5,- 7*1.9);
	}
	else
		PIEsetAreaOfInterest(-11, 7,12,- 7);
	
	//PIEsetAreaOfInterest(-11, 5,12,- 7);
}

function initialisescene()
{
	//PIEscene.background = new THREE.Color( 0x287A4C );
	
	var geometry = new THREE.PlaneGeometry( 500, 200, 4 );
	//var material = new THREE.MeshBasicMaterial( {color: 0x003300, side: THREE.DoubleSide} );
	var material = new THREE.MeshBasicMaterial( {color: 0x329acd, side: THREE.DoubleSide} );
	var plane = new THREE.Mesh( geometry, material );
	plane.position.set(0,0,-100);
	PIEaddElement( plane );
	
	var light =new THREE.PointLight( 0xffff66 ,0.7,100);
	light.position.set(0,0,50);
	PIEaddElement(light);	
}

function PIEcreateTable(i,n,g,d)
{
	var c;var b;var m;var f;var a;var h;var l;var k;var j;var e;PIEtableChangeHandlers.push(null);PIEtableNames.push(i);PIEtableRows.push(new Array(0));PIEtableData.push(new Array(0));PIEtableChangeHandlers.push(null);PIEcurrentTable=PIEtableNames.length-1;c=document.createElement("div");c.draggable=true;c.addEventListener("dragstart",PIEtableDragStart,false);c.id="mytable";c.style.border="2px solid white";c.style.borderRadius="10px";c.style.display="inline-block";c.style.position="absolute";c.style.top="60px";c.style.color="white";document.body.appendChild(c);b=document.createElement("div");b.style.display="inline-block";b.style.width="100%";b.style.padding="0px";c.appendChild(b);m=document.createElement("p");m.style.display="inline-block";m.style.width="100%";m.style.margin="auto";m.style.border="2 px solid white";m.style.borderRadius="10px";m.style.backgroundColor="#0020AA";b.appendChild(m);f=document.createElement("button");f.style.background="none";f.style.border="none";f.style.boxSizing="border-box";a=document.createElement("img");a.src="../PIE/images/TableAdd.png";a.alt="add";a.height="16";a.width="16";a.style.display="inline";f=document.createElement("button");f.style.background="none";f.style.border="none";f.style.boxSizing="border-box";a=document.createElement("img");a.src="../PIE/images/TableDelete.png";a.alt="delete";a.height="16";a.width="16";a.style.display="inline";a=document.createElement("span");a.style.padding="5px";a.style.margin="auto";a.style.align="center";a.innerHTML="<b>"+i+"</b>";m.appendChild(a);f=document.createElement("button");f.style.background="none";f.style.border="none";f.style.boxSizing="border-box";f.style.align="right";f.addEventListener("click",PIEtoggleTable,false);m.appendChild(f);a=document.createElement("img");a.src="../PIE/images/TableFold.png";a.alt="delete";a.height="16";a.width="16";a.style.display="inline";f.appendChild(a);a=document.createElement("div");h=document.createElement("table");h.style.display="inline-block";h.style.border="1px solid white";h.style.borderRadius="10px";h.style.padding="0px";h.style.backgroundColor="#0040BB";PIEtables.push(h);a.appendChild(h);c.appendChild(a);for(j=0;j<n;j++){for(e=0;e<g;e++){if(j==0){k=PIEcreateTableCell(j,e,d)}else{k=PIEcreateTableCell(j,e,false)}}}PIEupdateTable(PIEtables[PIEcurrentTable])
}

function PIEcreateTable1(i,n,g,d)
{
	var c;var b;var m;var f;var a;var h;var l;var k;var j;var e;PIEtableChangeHandlers.push(null);PIEtableNames.push(i);PIEtableRows.push(new Array(0));PIEtableData.push(new Array(0));PIEtableChangeHandlers.push(null);PIEcurrentTable=PIEtableNames.length-1;c=document.createElement("div");c.draggable=true;c.addEventListener("dragstart",PIEtableDragStart,false);c.id="mytable2";c.style.border="2px solid white";c.style.borderRadius="10px";c.style.display="inline-block";c.style.position="absolute";c.style.top="60px";c.style.color="white";document.body.appendChild(c);b=document.createElement("div");b.style.display="inline-block";b.style.width="100%";b.style.padding="0px";c.appendChild(b);m=document.createElement("p");m.style.display="inline-block";m.style.width="100%";m.style.margin="auto";m.style.border="2 px solid white";m.style.borderRadius="10px";m.style.backgroundColor="#0020AA";b.appendChild(m);f=document.createElement("button");f.style.background="none";f.style.border="none";f.style.boxSizing="border-box";a=document.createElement("img");a.src="../PIE/images/TableAdd.png";a.alt="add";a.height="16";a.width="16";a.style.display="inline";f=document.createElement("button");f.style.background="none";f.style.border="none";f.style.boxSizing="border-box";a=document.createElement("img");a.src="../PIE/images/TableDelete.png";a.alt="delete";a.height="16";a.width="16";a.style.display="inline";a=document.createElement("span");a.style.padding="5px";a.style.margin="auto";a.style.align="center";a.innerHTML="<b>"+i+"</b>";m.appendChild(a);f=document.createElement("button");f.style.background="none";f.style.border="none";f.style.boxSizing="border-box";f.style.align="right";f.addEventListener("click",PIEtoggleTable,false);m.appendChild(f);a=document.createElement("img");a.src="../PIE/images/TableFold.png";a.alt="delete";a.height="16";a.width="16";a.style.display="inline";f.appendChild(a);a=document.createElement("div");h=document.createElement("table");h.style.display="inline-block";h.style.border="1px solid white";h.style.borderRadius="10px";h.style.padding="0px";h.style.backgroundColor="#0040BB";PIEtables.push(h);a.appendChild(h);c.appendChild(a);for(j=0;j<n;j++){for(e=0;e<g;e++){if(j==0){k=PIEcreateTableCell(j,e,d)}else{k=PIEcreateTableCell(j,e,false)}}}PIEupdateTable(PIEtables[PIEcurrentTable])
}

function editable()
{
	PIEtableSelect("Experimental Data");
    PIEupdateTableCell(tableindex1,0,voltage);
	PIEupdateTableCell(tableindex1,1,water);
	PIEupdateTableCell(tableindex1,2,resistance);
}

function editable1()
{
	PIEtableSelect("Experimental Data.");
    PIEupdateTableCell(2,0,voltage);
	PIEupdateTableCell(2,1,water);
	PIEupdateTableCell(2,2,resistance);
}

function appendtable()
{
    if(tableindex1!=6)
			tableindex1++;
	else
	{
		alert("Reset Experiment to Continue with the Experiment");
		tableindex1=7;
		PIEstopAnimation();
	}
}

function resettable()
{
	PIEtableSelect("Experimental Data");
	
	PIEupdateTableCell(3,0,"-");
	PIEupdateTableCell(3,1,"-");
	PIEupdateTableCell(3,2,"-");
	PIEupdateTableCell(3,3,"-");
	PIEupdateTableCell(3,4,"-");
	PIEupdateTableCell(3,5,"-");
	PIEupdateTableCell(3,6,"-");
	
	PIEupdateTableCell(4,0,"-");
	PIEupdateTableCell(4,1,"-");
	PIEupdateTableCell(4,2,"-");
	PIEupdateTableCell(4,3,"-");
	PIEupdateTableCell(4,4,"-");
	PIEupdateTableCell(4,5,"-");
	PIEupdateTableCell(4,6,"-");
	
	PIEupdateTableCell(5,0,"-");
	PIEupdateTableCell(5,1,"-");
	PIEupdateTableCell(5,2,"-");
	PIEupdateTableCell(5,3,"-");
	PIEupdateTableCell(5,4,"-");
	PIEupdateTableCell(5,5,"-");
	PIEupdateTableCell(5,6,"-");
	
	PIEupdateTableCell(6,0,"-");
	PIEupdateTableCell(6,1,"-");
	PIEupdateTableCell(6,2,"-");
	PIEupdateTableCell(6,3,"-");
	PIEupdateTableCell(6,4,"-");
	PIEupdateTableCell(6,5,"-");
	PIEupdateTableCell(6,6,"-");
	
	PIEtableSelect("Experimental Data.");
	PIEupdateTableCell(2,0,"-");
	PIEupdateTableCell(2,1,"-");
	PIEupdateTableCell(2,2,"-");
	PIEupdateTableCell(2,3,"-");
	
}

function learningmode()
{
	PIEchangeInputCheckbox("Learning Mode", true, learningmode);
	PIEchangeInputCheckbox("Experiment Mode", false, learningmode);
	document.getElementById("mytable").style.visibility="hidden";
	document.getElementById("mytable2").style.visibility="visible";
	lm=1;
	var a=Math.floor(Math.random()*200+250);
	voltagecontrol(a);
	var b=Math.floor(Math.random()*900+100);
	b=Math.round(b/10);
	b=b*10;
	resistancecontrol(b);
	var c=Math.floor(Math.random()*700+300);
	c=Math.round(c/100);
	c=c*100;
	watercontrol(c);
	PIEchangeInputSlider("Voltage(Volt)",a);
	PIEchangeInputSlider("Resistance(Ohm)",b);
	PIEchangeInputSlider("Water(mL)",c);
	lscreen.visible=true;
	PIErender();
}

function experimentmode()
{
	PIEchangeInputCheckbox("Learning Mode", false, learningmode);
	PIEchangeInputCheckbox("Experiment Mode", true, learningmode);
	document.getElementById("mytable").style.visibility="visible";
	document.getElementById("mytable2").style.visibility="hidden";
	lm=0;
	lscreen.visible=false;
	PIErender();
}

function bubblemanagement()
{
	if(resistance==1000)
	{
		var q=Math.round(Math.random()*9+1);
		if(q==1)
		bubble1.visible=true;
		if(q==2)
		bubble2.visible=true;
		if(q==3)
		bubble3.visible=true;
		if(q==4)
		bubble4.visible=true;
		if(q==5)
		bubble5.visible=true;
		if(q==6)
		bubble6.visible=true;
		if(q==7)
		bubble7.visible=true;
		if(q==8)
		bubble8.visible=true;
		if(q==9)
		bubble9.visible=true;
		if(q==10)
		bubble10.visible=true;
	}
	else if(resistance>=700)
	{
		var q=Math.round(Math.random()*8+1);
		if(q==1)
		bubble1.visible=true;
		if(q==2)
		bubble2.visible=true;
		if(q==3)
		bubble3.visible=true;
		if(q==4)
		bubble4.visible=true;
		if(q==5)
		bubble5.visible=true;
		if(q==6)
		bubble6.visible=true;
		if(q==7)
		bubble7.visible=true;
		if(q==8)
		bubble8.visible=true;
		if(q==9)
		bubble9.visible=true;
	}
	else if(resistance>=500)
	{
		var q=Math.round(Math.random()*6+2);
		if(q==2)
		bubble2.visible=true;
		if(q==3)
		bubble3.visible=true;
		if(q==4)
		bubble4.visible=true;
		if(q==5)
		bubble5.visible=true;
		if(q==6)
		bubble6.visible=true;
		if(q==7)
		bubble7.visible=true;
		if(q==8)
		bubble8.visible=true;
	}
	else if(resistance>=300)
	{
		var q=Math.round(Math.random()*4+3);
		if(q==3)
		bubble3.visible=true;
		if(q==4)
		bubble4.visible=true;
		if(q==5)
		bubble5.visible=true;
		if(q==6)
		bubble6.visible=true;
		if(q==7)
		bubble7.visible=true;
	}
	else
	{
		var q=Math.round(Math.random()*3+3);
		if(q==3)
		bubble3.visible=true;
		if(q==4)
		bubble4.visible=true;
		if(q==5)
		bubble5.visible=true;
		if(q==6)
		bubble6.visible=true;
	}	
}

function cooldown()
{
		torus.material.color.set(0xa4672d);
		torus1.material.color.set(0xa4672d);
		torus2.material.color.set(0xa4672d);
		torus3.material.color.set(0xa4672d);
		torus4.material.color.set(0xa4672d);
		torus5.material.color.set(0xa4672d);
		torus6.material.color.set(0xa4672d);
		torus7.material.color.set(0xa4672d);
		torus8.material.color.set(0xa4672d);
		torus9.material.color.set(0xa4672d);
}

function nobubbles()
{
		bubble1.visible=false;
		bubble2.visible=false;
		bubble3.visible=false;
		bubble4.visible=false;
		bubble5.visible=false;
		bubble6.visible=false;
		bubble7.visible=false;
		bubble9.visible=false;
		bubble8.visible=false;
		bubble10.visible=false;
		
		bubble1.position.set(5.85,-5.3,0);
		bubble2.position.set(5.85+0.15+0.02,-5.3,0);
		bubble3.position.set(5.85+0.30+0.02,-5.3,0);
		bubble4.position.set(5.85+0.45+0.02,-5.3,0);
		bubble5.position.set(5.85+0.60+0.02,-5.3,0);
		bubble6.position.set(5.85+0.75+0.02,-5.3,0);
		bubble7.position.set(5.85+0.90+0.02,-5.3,0);
		bubble8.position.set(5.85+1.05+0.02,-5.3,0);
		bubble9.position.set(5.85+1.2+0.02,-5.3,0);
		bubble10.position.set(5.85+1.35+0.02,-5.3,0);
}

function addElementsToScene()
{
	voltage=5;
	resistance=100;
	water=2;
	flag=0;
	test=0;
	test2=0;
	flag2=0;
	check=1;
	time=0;
	lm=0;
	tableindex1=3;
	PIEaddInputSlider("Voltage(Volt)", 250, voltagecontrol, 250, 450, 1);
	PIEaddInputSlider("Resistance(Ohm)", 100, resistancecontrol, 100, 1000, 10);
	PIEaddInputSlider("Water(mL)", 300, watercontrol, 300, 1000, 100);
	
	PIEaddInputCheckbox("Learning Mode", false, learningmode);
	PIEaddInputCheckbox("Experiment Mode", true, experimentmode);
	
	PIEcreateTable("Experimental Data", 7, 6, true);
    var headerRow=["Voltage", "Water", "Resis.", "Time","Electric","Heat"];
	PIEupdateTableRow(0, headerRow);
	var headerRow=["","","","","Energy","Energy"];
	PIEupdateTableRow(1,headerRow);
	var headerRow=["(V)","(mL)","(Ohm)","(sec)","(J)","(J)"];
	PIEupdateTableRow(2,headerRow);
	
	PIEcreateTable1("Experimental Data.",4,4,true);
	var headerRow=["Voltage", "Water", "Resis.", "Time"];
	PIEupdateTableRow(0,headerRow);
	var headerRow=["(V)","(mL)","(Ohm)","(sec)"];
	PIEupdateTableRow(1,headerRow);
	
	document.getElementById("mytable2").style.visibility="hidden";
	
	resettable();
	addResistance();
	addContainer();
	addThermometer();
	watercontrol(300);
	resistancecontrol(100);
	voltagecontrol(250);
	powercontrol(0);
	addJoulesmeter();
	addclock();
	addclocktext();
	addSwitch();
	addBubble();
	learningthings();
	addVoltagesource();
	PIErender();
}

function PIEstartAnimation()
{
	if(PIEanimationON==false){PIElastUpdateTime=Date.now();PIEpauseOffset=0;PIEcurrentTime=0;PIEoffsetTime=0;PIEanimationON=true;PIEanimationPaused=false;PIEresumeButton.style.display="none";PIEresumeButton.style.visibility="hidden";PIEpauseButton.style.display="inline";PIEpauseButton.style.visibility="visible";PIEstartButton.style.display="none";PIEstopButton.style.display="inline";PIEshowDisplayPanel();PIEanimate()}
	switchon();
	powercontrol(voltage);
	clockzero();
	thermozero();
	degree.position.set(1.07,0.07,0.2);
	calspeed();
	if(lm==0)
	editable();
	else
	editable1();
	a=0;
	b=0;
	c=0;
	t=27;
	tempint=27;
	time=0;
	//bubblemanagement();
	cooldown();
	PIErender();
	flag=1;
}

function PIEstopAnimation()
{
	if(PIEanimationON==true){PIEpauseOffset=0;PIEcurrentTime=0;PIEoffsetTime=0;PIEanimationON=false;PIEanimationPaused=false;PIEresumeButton.style.display="none";PIEresumeButton.style.visibility="hidden";PIEpauseButton.style.display="inline";PIEpauseButton.style.visibility="hidden";PIEstopButton.style.display="none";PIEstartButton.style.display="inline";PIEshowInputPanel()}
	switchoff();
	PIErender();
	if(lm==0)
	appendtable();
	if(lm==1)
	powercontrol(voltage);
	else
	powercontrol(0);
	//cooldown();
	nobubbles();
	flag=0;
}

function resetExperiment()
{
	//PIEstopAnimation();
	resettable();
	experimentmode();
	watercontrol(300);
	resistancecontrol(100);
	voltagecontrol(250);
	clockzero();
	time=0;
	tableindex1=3;
	thermozero();
	PIEchangeInputSlider("Voltage(Volt)",250);
	PIEchangeInputSlider("Resistance(Ohm)",100);
	PIEchangeInputSlider("Water(mL)",300);
}

function updateExperimentElements(t, dt) 
{
	if(temp)
thermoinner.position.y=temp/35+0.15;

a++;
if(a>43)
{
	a=0;
	b++;
	time++;
}
if(b>59)
{
	c++;
	b=0;
}
if(c==60)
{
	clockzero();
}
if(b>0)
sec[b-1].visible=false;
else
{
	if(sec[59])
sec[59].visible=false;
}
if(c>0)
min[c-1].visible=false;
if(sec[b])
sec[b].visible=true;
if(sec[c])
min[c].visible=true;


temp = 27 + (power*time*1000)/(water*4186);

if(Math.round(temp)<101)
{
if(tempint != Math.round(temp))
{
	if(tempint)
	{
	t = tempint;
	tempint = Math.round(temp);
	check=0;
	}
}
if(check==0 && reading.length==74 )
{
	reading[tempint-27].visible=true;
	check=1;
	//alert(t);
	reading[t-27].visible=false;
}
}
else
{
	degree.position.set(1.14,0.07,0.2);
	PIEstopAnimation();
}
if(tableindex1!=0&&lm==0)
{
PIEtableSelect("Experimental Data");
PIEupdateTableCell(tableindex1,3,time);
PIEupdateTableCell(tableindex1,4,(power*time).toFixed(2));
PIEupdateTableCell(tableindex1,5,(power*time).toFixed(2));
}
if(lm==1)
{
PIEtableSelect("Experimental Data.");
PIEupdateTableCell(2,3,time);
}
x=(power*time).toFixed(2);


if(temp>27&&temp<=29)
{
		torus.material.color.set(0xce8500);
		torus1.material.color.set(0xce8500);
		torus2.material.color.set(0xce8500);
		torus3.material.color.set(0xce8500);
		torus4.material.color.set(0xce8500);
		torus5.material.color.set(0xce8500);
		torus6.material.color.set(0xce8500);
		torus7.material.color.set(0xce8500);
		torus8.material.color.set(0xce8500);
		torus9.material.color.set(0xce8500);
}

else if(temp>29&&temp<=33)
{
		torus.material.color.set(0xe59400);
		torus1.material.color.set(0xe59400);
		torus2.material.color.set(0xe59400);
		torus3.material.color.set(0xe59400);
		torus4.material.color.set(0xe59400);
		torus5.material.color.set(0xe59400);
		torus6.material.color.set(0xe59400);
		torus7.material.color.set(0xe59400);
		torus8.material.color.set(0xe59400);
		torus9.material.color.set(0xe59400);
}
else if(temp>33&&temp<=35)
{
		torus.material.color.set(0xff6a32);
		torus1.material.color.set(0xff6a32);
		torus2.material.color.set(0xff6a32);
		torus3.material.color.set(0xff6a32);
		torus4.material.color.set(0xff6a32);
		torus5.material.color.set(0xff6a32);
		torus6.material.color.set(0xff6a32);
		torus7.material.color.set(0xff6a32);
		torus8.material.color.set(0xff6a32);
		torus9.material.color.set(0xff6a32);
}
else if(temp>35&&temp<40)
{
		torus.material.color.set(0xff5719);
		torus1.material.color.set(0xff5719);
		torus2.material.color.set(0xff5719);
		torus3.material.color.set(0xff5719);
		torus4.material.color.set(0xff5719);
		torus5.material.color.set(0xff5719);
		torus6.material.color.set(0xff5719);
		torus7.material.color.set(0xff5719);
		torus8.material.color.set(0xff5719);
		torus9.material.color.set(0xff5719);
}
else if(temp>40&&temp<=50)
{
		torus.material.color.set(0xff4500);
		torus1.material.color.set(0xff4500);
		torus2.material.color.set(0xff4500);
		torus3.material.color.set(0xff4500);
		torus4.material.color.set(0xff4500);
		torus5.material.color.set(0xff4500);
		torus6.material.color.set(0xff4500);
		torus7.material.color.set(0xff4500);
		torus8.material.color.set(0xff4500);
		torus9.material.color.set(0xff4500);
}
else if(temp>50&&temp<=70)
{
		torus.material.color.set(0xcc3700);
		torus1.material.color.set(0xcc3700);
		torus2.material.color.set(0xcc3700);
		torus3.material.color.set(0xcc3700);
		torus4.material.color.set(0xcc3700);
		torus5.material.color.set(0xcc3700);
		torus6.material.color.set(0xcc3700);
		torus7.material.color.set(0xcc3700);
		torus8.material.color.set(0xcc3700);
		torus9.material.color.set(0xcc3700);
}
else if(temp>70)
{
		torus.material.color.set(0x992900);
		torus1.material.color.set(0x992900);
		torus2.material.color.set(0x992900);
		torus3.material.color.set(0x992900);
		torus4.material.color.set(0x992900);
		torus5.material.color.set(0x992900);
		torus6.material.color.set(0x992900);
		torus7.material.color.set(0x992900);
		torus8.material.color.set(0x992900);
		torus9.material.color.set(0x992900);
	
}

if(t%100==0)
	bubblemanagement();

if(water==300)
	wcase=-4.2;
else if(water==400)
	wcase=-3.77;
else if(water==500)
	wcase=-3.27;
else if(water==600)
	wcase=-2.77;
else if(water==700)
	wcase=-2.27;
else if(water==800)
	wcase=-1.77;
else if(water==900)
	wcase=-1.27;
else
	wcase=-0.87;
if(temp<30)
{
		if(bubble1.position.y<wcase && bubble1.visible==true)
		{
		var k=Math.random()*0.004+0.002;
		bubble1.position.y+=k;
		}
		else if(bubble1.visible==true)
		{
			bubble1.visible=false;
			bubble1.position.set(5.85,-5.3,0);
			bflag=0;
		}
		
		if(bubble2.position.y<wcase&&bubble2.visible==true)
		{
		var k=Math.random()*0.004+0.002;
		bubble2.position.y+=k;
		}
		else if(bubble2.visible==true)
		{
			bubble2.visible=false;
			bubble2.position.set(5.85+0.15+0.02,-5.3,0);
			bflag=0;
		}
		if(bubble3.position.y<wcase&&bubble3.visible==true)
		{
		var k=Math.random()*0.004+0.002;
		bubble3.position.y+=k;
		}
		else if(bubble3.visible==true)
		{
			bubble3.visible=false;
			bubble3.position.set(5.85+0.30+0.02,-5.3,0);
			bflag=0;
		}
		if(bubble4.position.y<wcase&&bubble4.visible==true)
		{
		var k=Math.random()*0.004+0.002;
		bubble4.position.y+=k;
		}
		else if(bubble4.visible==true)
		{
			bubble4.visible=false;
			bubble4.position.set(5.85+0.45+0.02,-5.3,0);
			bflag=0;
		}
		if(bubble5.position.y<wcase&&bubble5.visible==true)
		{
		var k=Math.random()*0.004+0.002;
		bubble5.position.y+=k;
		}
		else if(bubble5.visible==true)
		{
			bubble5.visible=false;
			bubble5.position.set(5.85+0.60+0.02,-5.3,0);
			bflag=0;
		}
		if(bubble6.position.y<wcase&&bubble6.visible==true)
		{
		var k=Math.random()*0.004+0.002;
		bubble6.position.y+=k;
		}
		else if(bubble6.visible==true)
		{
			bubble6.visible=false;
			bubble6.position.set(5.85+0.75+0.02,-5.3,0);
			bflag=0;
		}
		if(bubble7.position.y<wcase&&bubble7.visible==true)
		{
		var k=Math.random()*0.004+0.002;
		bubble7.position.y+=k;
		}
		else if(bubble7.visible==true)
		{
			bubble7.visible=false;
			bubble7.position.set(5.85+0.90+0.02,-5.3,0);
			bflag=0;
		}
		if(bubble8.position.y<wcase&&bubble8.visible==true)
		{
		var k=Math.random()*0.004+0.002;
		bubble8.position.y+=k;
		}
		else if(bubble8.visible==true)
		{
			bubble8.visible=false;
			bubble8.position.set(5.85+1.05+0.02,-5.3,0);
			bflag=0;
		}
		if(bubble9.position.y<wcase&&bubble9.visible==true)
		{
		var k=Math.random()*0.004+0.002;
		bubble9.position.y+=k;
		}
		else if(bubble9.visible==true)
		{
			bubble9.visible=false;
			bubble9.position.set(5.85+1.2+0.02,-5.3,0);
			bflag=0;
		}
		if(bubble10.position.y<wcase&&bubble10.visible==true)
		{
		var k=Math.random()*0.004+0.002;
		bubble10.position.y+=k;
		}
		else if(bubble10.visible==true)
		{
			bubble10.visible=false;
			bubble10.position.set(5.85+1.35+0.02,-5.3,0);
			bflag=0;
		}
	
}
else
{
		if(bubble1.position.y<wcase && bubble1.visible==true)
		{
		var k=Math.random()*0.006+0.004;
		bubble1.position.y+=k;
		}
		else if(bubble1.visible==true)
		{
			bubble1.visible=false;
			bubble1.position.set(5.85,-5.3,0);
			bflag=0;
		}
		
		if(bubble2.position.y<wcase&&bubble2.visible==true)
		{
		var k=Math.random()*0.006+0.004;
		bubble2.position.y+=k;
		}
		else if(bubble2.visible==true)
		{
			bubble2.visible=false;
			bubble2.position.set(5.85+0.15+0.02,-5.3,0);
			bflag=0;
		}
		if(bubble3.position.y<wcase&&bubble3.visible==true)
		{
		var k=Math.random()*0.006+0.004;
		bubble3.position.y+=k;
		}
		else if(bubble3.visible==true)
		{
			bubble3.visible=false;
			bubble3.position.set(5.85+0.30+0.02,-5.3,0);
			bflag=0;
		}
		if(bubble4.position.y<wcase&&bubble4.visible==true)
		{
		var k=Math.random()*0.006+0.004;
		bubble4.position.y+=k;
		}
		else if(bubble4.visible==true)
		{
			bubble4.visible=false;
			bubble4.position.set(5.85+0.45+0.02,-5.3,0);
			bflag=0;
		}
		if(bubble5.position.y<wcase&&bubble5.visible==true)
		{
		var k=Math.random()*0.006+0.004;
		bubble5.position.y+=k;
		}
		else if(bubble5.visible==true)
		{
			bubble5.visible=false;
			bubble5.position.set(5.85+0.60+0.02,-5.3,0);
			bflag=0;
		}
		if(bubble6.position.y<wcase&&bubble6.visible==true)
		{
		var k=Math.random()*0.006+0.004;
		bubble6.position.y+=k;
		}
		else if(bubble6.visible==true)
		{
			bubble6.visible=false;
			bubble6.position.set(5.85+0.75+0.02,-5.3,0);
			bflag=0;
		}
		if(bubble7.position.y<wcase&&bubble7.visible==true)
		{
		var k=Math.random()*0.006+0.004;
		bubble7.position.y+=k;
		}
		else if(bubble7.visible==true)
		{
			bubble7.visible=false;
			bubble7.position.set(5.85+0.90+0.02,-5.3,0);
			bflag=0;
		}
		if(bubble8.position.y<wcase&&bubble8.visible==true)
		{
		var k=Math.random()*0.006+0.004;
		bubble8.position.y+=k;
		}
		else if(bubble8.visible==true)
		{
			bubble8.visible=false;
			bubble8.position.set(5.85+1.05+0.02,-5.3,0);
			bflag=0;
		}
		if(bubble9.position.y<wcase&&bubble9.visible==true)
		{
		var k=Math.random()*0.006+0.004;
		bubble9.position.y+=k;
		}
		else if(bubble9.visible==true)
		{
			bubble9.visible=false;
			bubble9.position.set(5.85+1.2+0.02,-5.3,0);
			bflag=0;
		}
		if(bubble10.position.y<wcase&&bubble10.visible==true)
		{
		var k=Math.random()*0.006+0.004;
		bubble10.position.y+=k;
		}
		else if(bubble10.visible==true)
		{
			bubble10.visible=false;
			bubble10.position.set(5.85+1.35+0.02,-5.3,0);
			bflag=0;
		}
	
}
}